<!DOCTYPE html>
<html>
<head>
    <title>Accepted</title>
</head>
<body>
    <h1>Accepted</h1>
    <p>Content: Congrats! here is your flag: SYC{AL3XEI_FAKE_FLAG}</p>
</body>
</html>
