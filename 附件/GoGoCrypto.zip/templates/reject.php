<!DOCTYPE html>
<html>
<head>
    <title>Rejected</title>
</head>
<body>
    <h1>Rejected</h1>
    <p>Content: Ohoh! You are not allowed to get the flag.</p>
</body>
</html>
